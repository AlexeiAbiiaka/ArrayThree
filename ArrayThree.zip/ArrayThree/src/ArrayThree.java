// **********************************************************************
// Programmer:	Alexei Abiiaka
// Class:		CS30S
//
// Assignment:	Array Three
//
// Description:	Making an array that makes random numbers
//
//
//	Input:		describe any input from keyboard or file
//
//  Output:		describe the result of your program
// ***********************************************************************


import javax.swing.*;
import java.util.Random;



public class ArrayThree
{  // begin class
	private static int[] ArrayThree;
	
	public static void main(String args[])
	{  // begin main
	// ***** declaration of constants *****
	
	// ***** declaration of variables *****
		String strall = "";
		int sumArray = 0;
		int average = 0;
		int max = 0;
		int min = 0;
	// ***** create objects *****
		
		
	// ***** create input stream *****
	
		//ConsoleReader console = new ConsoleReader(System.in);
		
	// ***** Print Banner *****
		Banner banner = new Banner("Array Excercise 1");
		banner.printBanner("Making Fibonacci Sequence");
		
		
	// ***** get input *****
		
		//Random rand = new Random(); 
	// ***** processing *****

		//ArrayThree = new int[10];
	
		
		
		for (int i = 0; i < 10; i++) {
			//ArrayThree[i] = rand.nextInt(40);
			//System.out.println(ArrayThree[i]);
			//sumArray = sumArray + ArrayThree[i];
			
		}
		
		
		genreateRandomArray();
		printArray(ArrayThree);
        sumArray=getSumArray(sumArray);
        max=getMaxArray();
		strall+="\nMax Number: ";
	  	strall+=max;

        min=getMinArray();
		strall+="\nMin Number: ";
	 	strall+=min;
	 	
        average=getAverage();
        
		strall="Sum Array: ";
		strall+=sumArray;
		average = sumArray / 10;
		strall+="\nAverage Number: ";
		strall+=average;
/**		
		int max = ArrayThree[0];
	  	int min = ArrayThree[0];
	  	for (int i = 1; i < 10; i++) {
	  		if (ArrayThree[i] > max)
	  			max = ArrayThree[i];
	  		if (ArrayThree[i] < min)
	  			min = ArrayThree[i];	
	  	}
*/  	
	  	strall+="\nMax Number: ";
	  	strall+=max;
	  	strall+="\nMin Number: ";
	 	strall+=min;
	  	
	// ***** output *****
	System.out.println("Sum Array: ");
	System.out.println(sumArray);
	System.out.println("Average Number: ");
	System.out.println(average);
 	System.out.println("Max Number: " + max);
  	System.out.println("Min Number: " + min);
  	
  	
  	
	// ***** closing message *****
		JOptionPane.showMessageDialog(null, strall);
		banner.endOfProcessing();
		

	
	}  // end main
	
	public static void printArray(int ArrayThree[]) {
		for (int i = 0; i < 10; i++) {
			System.out.println(ArrayThree[i]);
		}		
		
	}
	
	
	public static void genreateRandomArray() {
		Random rand = new Random(); 
		ArrayThree = new int[10];
		for (int i = 0; i < 10; i++) {
			ArrayThree[i] = rand.nextInt(40);
		}
	}
	
	
	public static int getSumArray(int sumArray) {
		for (int i = 0; i < 10; i++) {
			sumArray = sumArray + ArrayThree[i];
		}	
		
		return sumArray;
	}
	
	public static int getAverage() {
		int average;
		int sumArray=0;
		for (int i = 0; i < 10; i++) {
		 sumArray+=ArrayThree[i];
		}
		average = sumArray / 10;
		return average;
	}
	
	public static int getMaxArray() {
		int max=0;
		max = ArrayThree[0];
		for (int i = 1; i < 10; i++) {
			
			if (ArrayThree[i] > max)
	  			max = ArrayThree[i];
		}
		return max;
	}
	
	public static int getMinArray() {
		int min=0;
		min = ArrayThree[0];	
		for (int i = 1; i < 10; i++) {
		
			if (ArrayThree[i] < min)
	  			min = ArrayThree[i];	

		}
		return min;
	}

}  // end class






